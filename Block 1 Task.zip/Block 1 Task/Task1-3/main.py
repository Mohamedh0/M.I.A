from race_simulator import RaceSimulator

if __name__ == "__main__":
    race = RaceSimulator()
    race.start_race()